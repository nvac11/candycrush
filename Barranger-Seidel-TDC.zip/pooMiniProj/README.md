# candycrush
# compilation g++:
g++ main.cpp app.cpp DisplayMenu.cpp GridDisplay.cpp EventController.cpp grid.cpp -o game -lsfml-graphics -lsfml-window -lsfml-system
